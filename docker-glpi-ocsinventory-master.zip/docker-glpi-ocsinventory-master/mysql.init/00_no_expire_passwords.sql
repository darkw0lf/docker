SHOW GLOBAL VARIABLES LIKE 'default_password_lifetime';
SET GLOBAL default_password_lifetime = 0;
SHOW GLOBAL VARIABLES LIKE 'default_password_lifetime';
